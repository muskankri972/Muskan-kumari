/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;

class Main {

    public static void quickSort(int[] a, int low, int high) {
        if (low < high) {
            int p = partition(a, low, high);
            quickSort(a, low, p - 1);  
            quickSort(a, p + 1, high); 
        }
    }

    public static int partition(int[] a, int low, int high) {
        int pivot = a[low];   
        int start = low;
        int end = high;

        while (start < end) {

            
            while (start <= high && a[start] <= pivot) {
                start++;
            }

           
            while (a[end] > pivot) {
                end--;
            }

            if (start < end) {
                swap(a, start, end);
            }
        }

       
        swap(a, low, end);

        return end; 
    }

    public static void swap(int[] a, int i, int j) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    public static void main(String[] args) {
        int[] a = {7, 6, 10, 5, 9, 2, 1, 15, 7};

        System.out.println("Before Sorting:");
        for (int x : a) {
            System.out.print(x + " ");
        }

        quickSort(a, 0, a.length - 1);

        System.out.println("\n\nAfter Sorting:");
        for (int x : a) {
            System.out.print(x + " ");
        }
    }
}
