/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main{

    static int partition(int[] a, int low, int high) {
        int pivot = a[low];   
        int start = low + 1;
        int end = high;

        while (start <= end) {

            while (start <= high && a[start] <= pivot) {
                start++;
            }

            while (a[end] > pivot) {
                end--;
            }

            if (start < end) {
                
                int temp = a[start];
                a[start] = a[end];
                a[end] = temp;
            }
        }

      
        int temp = a[low];
        a[low] = a[end];
        a[end] = temp;

        return end; 
    }

    public static void main(String[] args) {
        int[] arr = {7, 6, 10, 5, 9, 2, 15, 1};

        int pivotIndex = partition(arr, 0, arr.length - 1);

        System.out.println("Pivot index: " + pivotIndex);
        System.out.print("Array after partition: ");
        for (int x : arr) {
            System.out.print(x + " ");
        }
    }
}